
new TerrainMaterial()
{
    diffuseMap = "levels/tig/art/terrains/Overlay_Grass-01";
    detailMap = "levels/tig/art/terrains/Grass-01-D";
    internalName = "groundmodel_asphalt1";
    diffuseSize = "150";
    detailDistance = "50";
    normalMap = "levels/tig/art/terrains/Grass-01-N";
    macroSize = "100";
    macroStrength = "0.4";
    macroDistance = "450";
    macroMap = "levels/tig/art/terrains/Macro_grass";
    detailSize = "3";
    detailStrength = "0.7";
    annotation = "GRASS_THAT_BEHAVES_LIKE_ASPHALT";
   groundmodelName = "GROUNDMODEL_ASPHALT1";
   persistentId = "69c0f743-48e0-40e0-9315-5394789609d3";
};
